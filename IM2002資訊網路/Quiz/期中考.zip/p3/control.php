<?php
	session_start();   // 啟用交談期 
	$file  = basename($_SERVER["PHP_SELF"],".php");
	$path  = realpath($file.".php");                    // 取得檔案實際路徑
	$parts = pathinfo($path);                           // 取得路徑資訊
	//echo "路徑: " . $parts["dirname"] . "<br/>";

	$writefile = $parts["dirname"] . "\\File3-out.txt";
	//echo "讀檔: " . $readfile . "   寫檔: " . $writefile . "<br/>";

	$fpout = fopen($writefile, "a");           // 開啟文字檔案(寫) 
	
	//設定 $count 變數用來暫存上站次數
	$count=1;
	//如果 Cookie 的 counter 變數不存在, 表示使用者第 1 次上站
	if( !isset($_COOKIE['counter']) ){
		//設定 Cookie 的 counter 變數值為 1, 7 天之後到期
		setcookie("counter", urldecode(1), time()+7*24*3600 );
		setcookie("name", urldecode($_POST["name"]));
		setcookie("time", urldecode(date("Y-m-d H:i:s")));
		$count = $_COOKIE['counter'];
		$name = $_COOKIE['name'];
		$time = $_COOKIE['time'];
	}
	else{
		//如果 Session 的 entered 變數存在, 表示使用者之前連線過此網頁,
		//此次連線可能是重新整理網頁的重複連線
		if ( isset($_SESSION['entered']) ) {
			$count = $_COOKIE['counter'];
			$name = $_COOKIE['name'];
			$time = $_COOKIE['time'];
		}
		else {
			//把讀取到的 Cookie 內容加 1, 成為本次上站次數
			$count = $_COOKIE['counter'] + 1;
			//將新的上站次數寫入 Cookie
			setcookie("counter", urldecode($count), time()+7*24*3600);
			setcookie("time",urldecode(date("Y-m-d H:i:s")));
			$count = $_COOKIE['counter'];
			$name = $_COOKIE['name'];
			$time = $_COOKIE['time'];
			fprintf($fpout, "%s,%s,%s\n", $_COOKIE['name'], $_COOKIE['counter'], $_COOKIE['time']);
		}
	}
	fclose($fpout); 
	//建立 Session 的 entered 變數, 設定其值為 True,
	//表示使用者已經進入本網頁
	$_SESSION["count"]=$count;
	$_SESSION["name"]=$name;
	$_SESSION["time"]=$time;
	header("Location: show.php");
?>