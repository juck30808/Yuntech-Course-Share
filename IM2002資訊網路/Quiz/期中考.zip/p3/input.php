<html>
	<head>
		<meta charset="utf-8" />
		<title>input.php</title>
	</head>
	<body>
		
		<form name="login" method="post" action="control.php">
			<h2>使用者資料</h2>
			姓名: <input type="text" name="name"/><br/><br/>
			<p>
			<input type="submit" name="fun" value="輸入"/>
		</form>
	</body>
</html>