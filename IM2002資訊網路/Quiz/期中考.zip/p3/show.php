<html>
	<head>
		<meta charset="utf-8" />
		<title>input.php</title>
	</head>
	<body>
		<?php session_start();   // 啟用交談期 ?>
		<form name="login" method="post" action="input.php">
			<h2>Cookie資料顯示</h2>
			使用者: <input type="text" name="name" value = <?php echo $_SESSION["name"] ?>><br/><br/>
			使用次數: <input type="text" name="count" value = <?php echo $_SESSION["count"] ?>><br/><br/>
			使用時間: <input type="text" name="time" value = <?php echo $_SESSION["time"] ?>><br/><br/>
			<p>
			<input type="submit" name="fun" value="回輸入畫面"/>
		</form>
	</body>
</html>