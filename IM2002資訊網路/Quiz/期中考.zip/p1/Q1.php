<html>
	<head>
		<meta charset="utf-8" />
		<title>Ch8_4_4.php</title>
	</head>
	<body>
		<?php
			if(isset($_POST["Name"])){
				$name = $_POST["Name"];
				print "姓名：" . $name . "<br/><br/>";
			}
			if(isset($_POST["age"])){
				$age = $_POST["age"];
				print "年齡：" . $age . "<br/><br/>";
			}			
			if(isset($_POST["Gender"])){
				$gender = $_POST["Gender"];
				switch($gender){
					case "male":
						print "性別：男<br/><br/>";
					case "female":
						print "性別：女<br/><br/>";
				}
			}
			if(isset($_POST["location"])){
				$location = $_POST["location"];
				switch($location){
					case "TW":
						print "出生地：台灣本島<br/><br/>";
					case "other":
						print "出生地：外島<br/><br/>";
				}
			}			
			if(isset($_POST["Job"])){
				$Job = $_POST["Job"];
				switch($Job){
					case "在職中":
						print "就業情況：在職中<br/><br/>";
					case "謀職中":
						print "就業情況：謀職中<br/><br/>";
					case "學生":
						print "就業情況：學生<br/><br/>";
				}
			}
			print "健身方法：";
			$x = "";
			if(isset($_POST["快走"])){
				$name = $_POST["快走"];
				$x = $x . "快走 , ";
			}
			if(isset($_POST["跑步"])){
				$name = $_POST["跑步"];
				$x = $x . "跑步 , ";
			}
			if(isset($_POST["游泳"])){
				$name = $_POST["游泳"];
				$x = $x . "游泳 , ";
			}
			if(isset($_POST["太極拳"])){
				$name = $_POST["太極拳"];
				$x = $x . "太極拳 , ";
			}
			$x = substr($x,0,-2);
			print $x . "<br/><br/>";
			if(isset($_POST["int"])){
				$int = $_POST["int"];
				print "興趣：" . $int . "<br/><br/>";
			}			
			if(isset($_POST["Suggest"])){
				$suggest = $_POST["Suggest"];
				print "補充說明：<br/>". nl2br($suggest);
			}
			
			
			
			
		?>
	</body>
</html>