<html>
	<head>
		<meta charset="utf-8" />
		<title>fail.php</title>
	</head>
	<body>
		<?php
			session_start();   // 啟用交談期

			if (!isset($_SESSION["fail"]))
				header("Location: login.php");
			elseif ($_SESSION["fail"] == "no")
				header("Location: login.php");
		?>


		<h2>登入失敗</h2>
		帳號：<?php echo $_SESSION["Account"]?><br/>
		訊息：<?php echo $_SESSION["message"]?><br/>
		<p>
		<form name="login" method="post" action="control.php">
			<input type="submit" name="fun" value="重新登入"/>
		</form>
	</body>
</html>