<html>
	<head>
		<meta charset="utf-8" />
		<title>success.php</title>
	</head>
	<body>
		<?php
			session_start();   // 啟用交談期

			if (!isset($_SESSION["success"])){
				header("Location: login.php");
			}
			elseif ($_SESSION["success"] == "no"){
				header("Location: login.php");
			}

		?>

		<form name="login" method="post" action="control.php">
			<h2>登入成功</h2>
			帳號：<?php echo $_SESSION["Account"]?><br/>
			<p>
			<input type="submit" name="fun" value="登出"/>
		</form>
	</body>
</html>