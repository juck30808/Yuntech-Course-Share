<?php
	session_start();   // 啟用交談期 	
	if (!($fun = "登入")) {
		if($fun = "重新登入"){
			$_SESSION["success"] = "no";
			$_SESSION["fail"] = "no";
			header("Location: login.php");
		}
		if($fun = "登出"){
			$_SESSION["success"] = "no";
			$_SESSION["fail"] = "no";
			header("Location: login.php");
		}
	}else{
		$message = "";
		if(($_POST["Account"]=="A10823701")&&($_POST["Password"]=="pwd1")){
			$fun="登入成功";
		}else if(($_POST["Account"]=="A10823702")&&($_POST["Password"]=="pwd2")){
			$fun="登入成功";
		}else if(($_POST["Account"]=="A10823703")&&($_POST["Password"]=="pwd3")){
			$fun="登入成功";
		}else if(($_POST["Account"]=="A10823704")&&($_POST["Password"]=="pwd4")){
			$fun="登入成功";
		}else if(($_POST["Account"]=="A10823705")&&($_POST["Password"]=="pwd5")){
			$fun="登入成功";
		}else if((((($_POST["Account"]=="A10823705")||($_POST["Account"]=="A10823704"))||(($_POST["Account"]=="A10823703")||($_POST["Account"]=="A10823702")))||($_POST["Account"]=="A10823701"))){
			$fun="登入失敗";
			$message = "!密碼錯誤!";
		}else{
			$fun="登入失敗";
			$message = "!帳號錯誤!";
		}
	}
	
	if ($fun == "登入成功") {
	    $_SESSION["success"] = "yes";
		$_SESSION["fail"] = "no";
		$_SESSION["Account"]=$_POST["Account"];
		header("Location: success.php");
	}elseif ($fun == "登入失敗") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "yes";
		$_SESSION["Account"]=$_POST["Account"];	
		$_SESSION["message"]=$message;	
		header("Location: fail.php");
	}elseif ($fun == "重新登入") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "no";
		header("Location: login.php");
	}elseif ($fun == "登出") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "no";
		header("Location: login.php");
	}
?>