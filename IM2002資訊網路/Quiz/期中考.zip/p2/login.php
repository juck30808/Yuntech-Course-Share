<html>
	<head>
		<meta charset="utf-8" />
		<title>login.php</title>
	</head>
	<body>
		<?php
			session_start();   // 啟用交談期

			if (isset($_SESSION["success"])){
				if ($_SESSION["success"] == "yes"){
					header("Location: success.php");
				}elseif ($_SESSION["fail"] == "yes"){ 
					header("Location: fail.php");
				}
			}elseif (isset($_SESSION["fail"])){
				if ($_SESSION["fail"] == "yes"){ 
					header("Location: fail.php");
				}
			}
		?>

		<form name="login" method="post" action="control.php">
			<h2>系統登入</h2>
			帳號: <input type="text" name="Account"/><br/><br/>
			密碼: <input type="password" name="Password"/><br/><br/>
			<p>
			<input type="submit" name="fun" value="登入"/>
			<input type="reset" value="清除"/>
		</form>
	</body>
</html>