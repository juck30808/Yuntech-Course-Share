<html>
	<head>
		<meta charset="utf-8" />
		<title>Ch8_4_4.php</title>
	</head>
	<body>
		<?php
			if(isset($_POST["Uid"])){
				$uid = $_POST["Uid"];
				print "學號：" . $uid . "<br/><br/>";
			}
			if(isset($_POST["Name"])){
				$name = $_POST["Name"];
				print "姓名：" . $name . "<br/><br/>";
			}
			if(isset($_POST["Gender"])){
				$gender = $_POST["Gender"];
				switch($gender){
					case "male":
						print "性別：男<br/><br/>";
					case "female":
						print "性別：女<br/><br/>";
				}
			}
			
			print "興趣：";
			$x = "";
			if(isset($_POST["寫程式"])){
				$name = $_POST["寫程式"];
				$x = $x . "寫程式 , ";
			}
			if(isset($_POST["上網"])){
				$name = $_POST["上網"];
				$x = $x . "上網 , ";
			}
			if(isset($_POST["逛街"])){
				$name = $_POST["逛街"];
				$x = $x . "逛街 , ";
			}
			if(isset($_POST["運動"])){
				$name = $_POST["運動"];
				$x = $x . "運動 , ";
			}
			$x = substr($x,0,-2);
			print $x . "<br/><br/>";
			
			if(isset($_POST["Expertise"])){
				$expertise = $_POST["Expertise"];
				switch($expertise){
					case "資訊技術":
						print "專長：資訊技術<br/><br/>";
					case "資訊管理":
						print "專長：資訊管理<br/><br/>";
				}
			}
			if(isset($_POST["Suggest"])){
				$suggest = $_POST["Suggest"];
				print "建議<br/>". nl2br($suggest);
			}
		?>
	</body>
</html>