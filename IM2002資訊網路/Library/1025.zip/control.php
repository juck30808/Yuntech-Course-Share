<?php
	session_start();   // 啟用交談期
	if (!$fun = "送出") {
		if($fun = "回系統登入畫面"){
			$_SESSION["success"] = "no";
			$_SESSION["fail"] = "no";
			header("Location: login.php");
		}
	}else{
		if((($_POST["StudentID"]=="9923701")&&($_POST["Password"]=="1073299"))&&($_POST["Name"]=="黃一")){
			$fun="登入成功";
		}else if((($_POST["StudentID"]=="9923702")&&($_POST["Password"]=="2073299"))&&($_POST["Name"]=="吳二")){
			$fun="登入成功";
		}else{
			$fun="登入失敗";
		}
	}
	
	if ($fun == "登入成功") {
	    $_SESSION["success"] = "yes";
		$_SESSION["fail"] = "no";
		$_SESSION["StudentID"]=$_POST["StudentID"];
		$_SESSION["Password"]=$_POST["Password"];
		$_SESSION["Name"]=$_POST["Name"];
		header("Location: success.php");
	}elseif ($fun == "登入失敗") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "yes";
		$_SESSION["StudentID"]=$_POST["StudentID"];
		$_SESSION["Password"]=$_POST["Password"];
		$_SESSION["Name"]=$_POST["Name"];
		header("Location: fail.php");
	}elseif ($fun == "重新登入") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "no";
		header("Location: login.php");
	}elseif ($fun == "回系統登入畫面") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "no";
		header("Location: login.php");
	}
?>