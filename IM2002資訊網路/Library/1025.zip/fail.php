<html>
	<head>
		<meta charset="utf-8" />
		<title>fail.php</title>
	</head>
	<body>
		<?php
			session_start();   // 啟用交談期

			if (!isset($_SESSION["fail"]))
				header("Location: login.php");
			elseif ($_SESSION["fail"] == "no")
				header("Location: login.php");
		?>


		<h2>登入失敗</h2>
		學號：<?php echo $_SESSION["StudentID"]?><br/>
		姓名：<?php echo $_SESSION["Name"]?><br/><br/>
		!系統登入失敗!
		<p>
		<form name="login" method="post" action="control.php">
			<input type="submit" name="fun" value="回系統登入畫面"/>
		</form>
	</body>
</html>