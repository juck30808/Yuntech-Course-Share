<html>
	<head>
		<meta charset="utf-8" />
		<title>1004</title>
	</head>
	<body>
		<?php			
			$Name = array("王一","張二","Ray","KiKi");
			$Ch = array(90,80,80,60);
			$Eng = array(100,85,65,85);
			$Math = array(80,90,90,80);
			$Grade = array($Name,$Ch,$Eng,$Math);
			function find($input,$Grade){
				if(in_array($input,$Grade[0])){
					$index = array_search($input,$Grade[0]);
					echo "姓名：" . $Grade[0][$index]."</br>";
					echo "國文：" . $Grade[1][$index]."</br>";
					echo "英文：" . $Grade[2][$index]."</br>";
					echo "數學：" . $Grade[3][$index]."</br>";
					$sum = $Grade[1][$index]+$Grade[2][$index]+$Grade[3][$index];
					echo "總分：" . $sum."</br>";
					$average = round((float)$sum/3,2);
					echo "平均：" . number_format($average, 2)."</br>";
				}else{
					echo "姓名：" . $input."</br>";
					echo "！學生不存在！" ."</br>";
				}
				echo "</p>";
			}
			find("張二",$Grade);
			find("Lin",$Grade);			
		?>
	</body>
</html>