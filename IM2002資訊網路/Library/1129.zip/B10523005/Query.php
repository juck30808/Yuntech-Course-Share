<html>
	<head>
		<meta charset="utf-8" />
		<title>1129.php</title>
	</head>
	<body>
		<h1>基本資料庫管理系統-查詢</h1>
		<hr>

		<?php
			// 是否是表單送回
			if (isset($_POST["Query"])) {
				session_start();   // 啟用交談期

				// 開啟MySQL的資料庫連接
				$link = mysqli_connect("localhost","root","","testdb")or die("無法開啟MySQL資料庫連接!<br>");
				
				// 建立查詢記錄的SQL指令字串
				$sql = "SELECT * FROM users ";
				$sql.= " WHERE 編號 IN (". $_POST["No"] . ")";
				//送出UTF8編碼的MySQL指令
				mysqli_query($link, 'SET NAMES utf8'); 
				
				// 執行SQL查詢
				$result = mysqli_query($link, $sql); 
				$_SESSION["sql"] = $sql;
				$_SESSION["No"] = $_POST["No"];
				if ( mysqli_fetch_row($result) == 0) { 
					header("Location: Fail.php"); 		
				} 
				else { 

					//$_SESSION["result"] = mysqli_query($link, $sql);
					header("Location: Successed.php");
				}

				mysqli_close($link);      // 關閉資料庫連接
			}
		?>
		<form method="post">
			<table border="0">
				<tr><td>編號:</td>
						
				<td><input type="text" name="No" size ="50"/></td>
				</tr>
			</table>
			<br>
			<input type="submit" name="Query" value="查詢"/>
			<input type="reset" value="清除">
		</form>
		<hr>
	</body>
</html>