<html>
	<head>
		<meta charset="utf-8" />
		<title>1129.php</title>
	</head>
	<body>
		<h1>基本資料庫管理系統-查詢</h1>
		<p><p>
		<?php
			session_start();   // 啟用交談期
			$No = $_SESSION["No"];
			// 建立MySQL的資料庫連接 
			$link = mysqli_connect("localhost","root","","testdb")or die("無法開啟MySQL資料庫連接!<br>");
			//  指定SQL查詢字串
			$sql = "SELECT * FROM users ";
			$sql.= " WHERE 編號 IN (". $No . ")";
			//送出UTF8編碼的MySQL指令
			mysqli_query($link, 'SET NAMES utf8'); 
			// 送出查詢的SQL指令
			$result = mysqli_query($link, $sql);
			$row = mysqli_fetch_row($result);
			$meta = mysqli_fetch_field($result);
			
			// 一筆一筆的以表格顯示記錄
			echo "<table border=0><tr>";
			// 顯示欄位名稱
			$i = 0;
			while ( $meta = mysqli_fetch_field($result) ){
				echo "<td>".$meta->name."</td>";
				echo "<td>".$row[$i]."</td>";
				echo "</tr>";
				$i++;
			}
			
			echo "</table>";
			mysqli_free_result($result); // 釋放佔用記憶體  
			mysqli_close($link);  // 關閉資料庫連接

		?>
		<p>
		<form method="post" action="Query.php">
			<input type="submit" value="回查詢畫面"/>
		</form>
		<hr>
	</body>
</html>