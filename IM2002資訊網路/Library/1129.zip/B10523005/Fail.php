<html>
	<head>
		<meta charset="utf-8" />
		<title>1129.php</title>
	</head>
	<body>
		<?php
			session_start();
			$No = $_SESSION["No"];
		?>
		<h1>基本資料庫管理系統-查詢</h1>
		<hr>
		編號：<?php echo $No ?>
		<p><p>
		<font color="red">!資料不存在!</font>
		<form method="post" action="Query.php">
			<input type="submit" value="回查詢畫面"/>
		</form>
		<hr>
	</body>
</html>