<html>
	<head>
		<meta charset="utf-8" />
		<title>success.php</title>
	</head>
	<body>
		<?php
			session_start();   // 啟用交談期

			if (!isset($_SESSION["success"])){
				header("Location: login.php");
			}
			elseif ($_SESSION["success"] == "no"){
				header("Location: login.php");
			}
            $avg = ($_SESSION["C"]+$_SESSION["E"]+$_SESSION["M"])/3
		?>

		<form name="login" method="post" action="control.php">
			<h2>學生成績</h2>
			學號：<input type="text" name="StudentID" value = <?php echo $_SESSION["StudentID"] ?> />
            登入次數：<input type="text" name="StudentID" value = <?php echo $_SESSION["count"] ?> /><br/><br/>
			國文：<input type="text" name="StudentID" value = <?php echo $_SESSION["C"] ?> /><br/>
			英文：<input type="text" name="StudentID" value = <?php echo $_SESSION["E"] ?> /><br/>
			數學：<input type="text" name="StudentID" value = <?php echo $_SESSION["M"] ?> /><br/>
			平均：<input type="text" name="StudentID" value = <?php echo $avg ?> /><br/><br/>
			<p>
			<input type="submit" name="fun" value="回登入畫面"/>
		</form>
	</body>
</html>