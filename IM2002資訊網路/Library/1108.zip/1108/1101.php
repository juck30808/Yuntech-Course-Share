<HTML>
	<HEAD>
		<meta charset="utf-8" />
		<TITLE>1101</TITLE>
	</HEAD>
	<BODY>
		<?php
			$file  = basename($_SERVER["PHP_SELF"],".php");
			$path  = realpath($file.".php");                    // 取得檔案實際路徑
			$parts = pathinfo($path);                           // 取得路徑資訊
			//echo "路徑: " . $parts["dirname"] . "<br/>";

			$readfile  = $parts["dirname"] . "\\p6_input.dat";
			//echo "讀檔: " . $readfile . "<br/>";
			$writefile = $parts["dirname"] . "\\p6_output.dat";
			//echo "讀檔: " . $readfile . "   寫檔: " . $writefile . "<br/>";

			$fpin  = fopen($readfile,  "r");           // 開啟文字檔案(讀) 
			$fpout = fopen($writefile, "w");           // 開啟文字檔案(寫) 
	
			$line = fscanf($fpin, "%s %s %s %s\n");  
			$index = 0;			
			while ($line != null) {
				$index++; 
				list($id, $name, $number, $price) = $line;
				echo $id . " " . $name . " " . $number . " " . $price . "<br/>";
				fprintf($fpout, "%s %s %s %s %s\n", $index, $id, $name, $number, $price);

				$line = fscanf($fpin, "%s %s %s %s %s\n");
			}
			fclose($fpin);
			fclose($fpout); 
		?>
	</BODY>
</HTML>