<html>
	<head>
		<meta charset="utf-8" />
		<title>fail.php</title>
	</head>
	<body>
		<?php
			session_start();   // 啟用交談期

			if (!isset($_SESSION["fail"]))
				header("Location: login.php");
			elseif ($_SESSION["fail"] == "no")
				header("Location: login.php");
		?>


		<h2>學生成績查詢系統</h2>
		
		學號: <input type="text" name="StudentID" value = <?php echo $_SESSION["StudentID"]?> /><br/><br/>
			
		!登入失敗!<br/><br/><br/><br/>
		<p>
		<form name="login" method="post" action="control.php">
			<input type="submit" name="fun" value="回登入畫面"/>
		</form>
	</body>
</html>