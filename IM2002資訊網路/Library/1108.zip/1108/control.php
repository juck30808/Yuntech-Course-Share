<?php
	session_start();   // 啟用交談期
	
	$file  = basename($_SERVER["PHP_SELF"],".php");
	$path  = realpath($file.".php");                    // 取得檔案實際路徑
	$parts = pathinfo($path);                           // 取得路徑資訊
	//echo "路徑: " . $parts["dirname"] . "<br/>";

	$readfile  = $parts["dirname"] . "\\score.dat";
	//echo "讀檔: " . $readfile . "<br/>";
	
	$fpin  = fopen($readfile,"r");           // 開啟文字檔案(讀) 
	$line = fscanf($fpin, "%s %s %s %s %s %s\n");  	
	
	if (!($_POST["fun"] == "登入")) {
		if($_POST["fun"] == "回登入畫面"){
			$_SESSION["success"] = "no";
			$_SESSION["fail"] = "no";
			header("Location: login.php");
		}
	}else{
		$flag = false;
		while (($line != null)&&($flag == false)) {
			list($id, $password, $name, $C, $E, $M) = $line;
			if(($_POST["StudentID"]==$id)&&($_POST["Password"]==$password)){
				$fun="登入成功";
				$flag = true;
				$ch = $C;
				$en = $E;
				$ma = $M;
			}
			$line = fscanf($fpin, "%s %s %s %s %s\n");
		}
		if($flag == false){
			$fun="登入失敗";
		}
	}
	
	if ($fun == "登入成功") {
		//設定 $count 變數用來暫存上站次數
		$count=1;
		//如果 Cookie 的 counter 變數不存在, 表示使用者第 1 次上站
		if( !isset($_COOKIE['counter']) ){
			//設定 Cookie 的 counter 變數值為 1, 7 天之後到期
			setcookie("counter", 1, time()+7*24*3600 );
		}
		else{
			//如果 Session 的 entered 變數存在, 表示使用者之前連線過此網頁,
			//此次連線可能是重新整理網頁的重複連線
			if ( isset($_SESSION['entered']) ) {
				$count = $_COOKIE['counter'];
			}
			else {
				//把讀取到的 Cookie 內容加 1, 成為本次上站次數
				$count = $_COOKIE['counter'] + 1;
				//將新的上站次數寫入 Cookie
				setcookie("counter", $count, time()+7*24*3600);
			}
		}
		//建立 Session 的 entered 變數, 設定其值為 True,
		//表示使用者已經進入本網頁

		$_SESSION["success"] = "yes";
		$_SESSION["fail"] = "no";
		$_SESSION["StudentID"]=$_POST["StudentID"];
		$_SESSION["C"]=$ch;
		$_SESSION["E"]=$en;
		$_SESSION["M"]=$ma;
        $_SESSION["count"] = $count;
		header("Location: success.php");
	}elseif ($fun == "登入失敗") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "yes";
		$_SESSION["StudentID"]=$_POST["StudentID"];
		header("Location: fail.php");
	}elseif ($fun == "回登入畫面") {
		$_SESSION["success"] = "no";
		$_SESSION["fail"] = "no";
		header("Location: login.php");
	}
?>