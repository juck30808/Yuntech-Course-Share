<meta charset="UTF-8">
非同步訊息

<?php
	$account = $_POST["account"];
	$password = $_POST["password"];
	$message = "";
	if((($account == 9923701) &&($password == 1073299)) ||(($account == 9923702) &&($password == 2073299))){
		$message = "登入成功";
	} else{
		$message = "登入失敗";
	}
?>
<br>
訊息欄：<INPUT TYPE="text" NAME="message" VALUE = "<?php echo $message; ?>">