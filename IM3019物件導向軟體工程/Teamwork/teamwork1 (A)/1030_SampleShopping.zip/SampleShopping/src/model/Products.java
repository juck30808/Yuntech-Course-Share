package model;

public class Products {
	private int PD_ID;
	private String PD_Name;
	private String PD_Brand;
	private String PD_type;
	private int PD_Price;
	private int PD_Quantity;
	private String PD_Photo;
	private String PD_Desc;
	public int getPD_ID() {
		return PD_ID;
	}
	public void setPD_ID(int pD_ID) {
		PD_ID = pD_ID;
	}
	public String getPD_Name() {
		return PD_Name;
	}
	public void setPD_Name(String pD_Name) {
		PD_Name = pD_Name;
	}
	public String getPD_Brand() {
		return PD_Brand;
	}
	public void setPD_Brand(String pD_Brand) {
		PD_Brand = pD_Brand;
	}
	public String getPD_type() {
		return PD_type;
	}
	public void setPD_type(String pD_type) {
		PD_type = pD_type;
	}
	public int getPD_Price() {
		return PD_Price;
	}
	public void setPD_Price(int pD_Price) {
		PD_Price = pD_Price;
	}
	public int getPD_Quantity() {
		return PD_Quantity;
	}
	public void setPD_Quantity(int pD_Quantity) {
		PD_Quantity = pD_Quantity;
	}
	public String getPD_Photo() {
		return PD_Photo;
	}
	public void setPD_Photo(String pD_Photo) {
		PD_Photo = pD_Photo;
	}
	public String getPD_Desc() {
		return PD_Desc;
	}
	public void setPD_Desc(String pD_Desc) {
		PD_Desc = pD_Desc;
	}
	
}
