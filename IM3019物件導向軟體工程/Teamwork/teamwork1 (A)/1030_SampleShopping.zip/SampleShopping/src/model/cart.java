package model;

public class cart {
	private int Shop_ID;
	private int User_ID;
	private int PD_ID;
	private int Shop_Quantity;
	public int getShop_ID() {
		return Shop_ID;
	}
	public void setShop_ID(int shop_ID) {
		Shop_ID = shop_ID;
	}
	public int getUser_ID() {
		return User_ID;
	}
	public void setUser_ID(int user_ID) {
		User_ID = user_ID;
	}
	public int getPD_ID() {
		return PD_ID;
	}
	public void setPD_ID(int pD_ID) {
		PD_ID = pD_ID;
	}
	public int getShop_Quantity() {
		return Shop_Quantity;
	}
	public void setShop_Quantity(int shop_Quantity) {
		Shop_Quantity = shop_Quantity;
	}
	
}
