package shoppingCartCommand;

public interface command {
	public abstract void execute();
}
