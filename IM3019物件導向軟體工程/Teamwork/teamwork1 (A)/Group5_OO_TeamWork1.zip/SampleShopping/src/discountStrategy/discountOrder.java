package discountStrategy;


public class discountOrder {
	
	public void process (discountParent discount) {
			discount.doDiscount();
	}
}
