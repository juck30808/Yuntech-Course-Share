import static org.junit.Assert.*;
import java.io.*;
import org.junit.Test;
import static org.mockito.*;
import java.util.*;
import java.io.IOException;
import DAO.*;
import com.SampleShopping.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class JunitTest {

	@Test
	public void addtocart_nologin() {

	    HttpServletRequest request = mock(HttpServletRequest.class);       
        HttpServletResponse response = mock(HttpServletResponse.class); 
		String TB_User_Acc = "noadmin";
		String TB_User_Pwd = "12345";
		response.sendRedirect("login");
		String User_ID = usersDAO.getUser_Infor(TB_User_Acc, TB_User_Pwd, "User_ID");
		String quantity = "2";
		String pid = "3";
		response.sendRedirect("addtocart");
	}
	public void addtocart_haslogin_noStock() {

	    HttpServletRequest request = mock(HttpServletRequest.class);       
        HttpServletResponse response = mock(HttpServletResponse.class); 
		String TB_User_Acc = "admin";
		String TB_User_Pwd = "12345";
		response.sendRedirect("login");
		String User_ID = usersDAO.getUser_Infor(TB_User_Acc, TB_User_Pwd, "User_ID");
		String quantity = "2";
		String pid = "1"; //pid 1 hasn't stock
		response.sendRedirect("addtocart");
		
	}
	
	public void addtocart_haslogin_hasStock_noexist() {

	    HttpServletRequest request = mock(HttpServletRequest.class);       
        HttpServletResponse response = mock(HttpServletResponse.class); 
		String TB_User_Acc = "admin";
		String TB_User_Pwd = "12345";
		response.sendRedirect("login");
		String User_ID = usersDAO.getUser_Infor(TB_User_Acc, TB_User_Pwd, "User_ID");
		String quantity = "2";
		String pid = "4"; //pid 4 has stock
		response.sendRedirect("addtocart");
		
	}
	
	public void addtocart_haslogin_hasStock_exist() {

	    HttpServletRequest request = mock(HttpServletRequest.class);       
        HttpServletResponse response = mock(HttpServletResponse.class); 
		String TB_User_Acc = "admin";
		String TB_User_Pwd = "12345";
		response.sendRedirect("login");
		String User_ID = usersDAO.getUser_Infor(TB_User_Acc, TB_User_Pwd, "User_ID");
		String quantity = "2";
		String pid = "4"; //pid 4 has stock
		response.sendRedirect("addtocart");
		quantity = "2";
		pid = "4"; //pid 4 has stock
		response.sendRedirect("addtocart");
		
	}

}
