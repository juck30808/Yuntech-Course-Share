package ProxyProtection;

public class Whiskey implements Liquor{
	public void sell() {
		System.out.println("selling this Whiskey ....");
	}
}
