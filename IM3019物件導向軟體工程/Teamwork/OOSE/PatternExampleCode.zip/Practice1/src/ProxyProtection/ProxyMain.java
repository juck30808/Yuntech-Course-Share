package ProxyProtection;

public class ProxyMain {
	public static void main(String[] args) {
		WhiskeyProxy p = new WhiskeyProxy();
		p.setAge(10);
		p.sell();
		p.setAge(20);
		p.sell();
	}
}
