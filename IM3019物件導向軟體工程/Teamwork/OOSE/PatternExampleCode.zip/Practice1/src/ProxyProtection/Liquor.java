package ProxyProtection;

public interface Liquor {
	public void sell();
}
