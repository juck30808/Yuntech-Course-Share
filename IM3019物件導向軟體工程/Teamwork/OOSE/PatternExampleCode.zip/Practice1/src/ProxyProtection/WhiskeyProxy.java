package ProxyProtection;

public class WhiskeyProxy implements Liquor{
	private int age = 0;
	Whiskey w = null;
	public void sell() {
		if(age >=18) {
			w = new Whiskey();
			w.sell();
		}else {
			System.out.println("You can't buy Liquor");
		}
	}
	public void setAge(int age) {
		this.age = age;
	}
}
