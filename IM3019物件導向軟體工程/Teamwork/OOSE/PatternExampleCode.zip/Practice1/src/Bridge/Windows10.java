package Bridge;

public class Windows10 implements OS{
	@Override
	public void startOS() {
		System.out.println("Windows10 starting");
	}
}
