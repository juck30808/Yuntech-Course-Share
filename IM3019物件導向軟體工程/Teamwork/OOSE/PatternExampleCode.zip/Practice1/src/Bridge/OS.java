package Bridge;

public interface OS {
	public void startOS();
}
