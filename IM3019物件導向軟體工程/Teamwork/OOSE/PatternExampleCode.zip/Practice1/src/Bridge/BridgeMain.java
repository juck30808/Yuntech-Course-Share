package Bridge;

public class BridgeMain {
	public static void main(String[] args) {
		UI x = new GuiUI();
		x.setOS(new Windows10());
		x.start();
		System.out.println("*******");
		UI y = new CmdUI();
		y.setOS(new Windows10());
		y.start();
		System.out.println("*******");
		UI z = new GuiUI();
		z.setOS(new CentOS());
		z.start();
		System.out.println("*******");
		UI w = new CmdUI();
		w.setOS(new CentOS());
		w.start();
	}
}
