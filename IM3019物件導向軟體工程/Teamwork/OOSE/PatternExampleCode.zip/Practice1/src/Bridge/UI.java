package Bridge;

public abstract class UI {
	OS os;
	public void setOS(OS s) {
		this.os = s;
	}
	public abstract void start();
}