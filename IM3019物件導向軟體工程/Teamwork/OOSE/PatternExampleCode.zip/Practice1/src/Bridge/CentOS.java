package Bridge;

public class CentOS implements OS{
	@Override
	public void startOS() {
		System.out.println("CentOS starting");
	}
}
