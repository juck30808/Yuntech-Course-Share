package Bridge;

public class CmdUI extends UI{
	@Override
	public void start() {
		System.out.println("Using CmdUI");
		os.startOS();
	}
}
