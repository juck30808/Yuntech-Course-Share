package Bridge;

public class GuiUI extends UI{
	@Override
	public void start() {
		System.out.println("Using GuiUI");
		os.startOS();
	}
}
