package Visitor;

public class NormalVisitor implements Visitor{
	public void visitor(Liquor l) {
		System.out.println("This Liquor is $" + l.getPrice());
	}
	public void visitor(Pork p) {
		System.out.println("This Pork is $" + p.getPrice());
	}
	public void visitor(Candy c) {
		System.out.println("This Candy is $" + c.getPrice());
	}
}
