package Visitor;

public class VisitorMain {
	public static void main(String[] args) {
		Liquor l = new Liquor(500);
		Pork p = new Pork(200);
		Candy c = new Candy(50);
		Visitor normal = new NormalVisitor();
		Visitor discount = new DiscountVisitor();
		l.accept(normal);
		p.accept(normal);
		c.accept(normal);
		System.out.println("----------");
		l.accept(discount);
		p.accept(discount);
		c.accept(discount);
	}
}
