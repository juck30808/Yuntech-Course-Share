package Visitor;

public interface Stuff {
	public void accept(Visitor v);
}
