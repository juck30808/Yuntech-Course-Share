package Visitor;

public class DiscountVisitor implements Visitor{
	public void visitor(Liquor l) {
		System.out.println("This Liquor after discount is $" + l.getPrice()*0.99);
	}
	public void visitor(Pork p) {
		System.out.println("This Pork after discount is $" + p.getPrice()*0.90);
	}
	public void visitor(Candy c) {
		System.out.println("This Candy after discount is $" + c.getPrice()*0.5);
	}
}
