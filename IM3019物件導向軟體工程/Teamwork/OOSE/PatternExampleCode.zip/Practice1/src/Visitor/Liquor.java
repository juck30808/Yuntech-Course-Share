package Visitor;

public class Liquor implements Stuff{
	private int price;
	public Liquor(int price) {
		this.price = price;
	}
	public void accept(Visitor v) {
		v.visitor(this);
	}
	public int getPrice() {
		return price;
	}
}
