package Visitor;

public interface Visitor {
	public void visitor(Liquor l);
	public void visitor(Pork p);
	public void visitor(Candy c);
}
