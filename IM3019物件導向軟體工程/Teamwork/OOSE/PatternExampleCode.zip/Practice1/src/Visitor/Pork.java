package Visitor;

public class Pork implements Stuff{
	private int price;
	public Pork(int price) {
		this.price = price;
	}
	public void accept(Visitor v) {
		v.visitor(this);
	}
	public int getPrice() {
		return price;
	}
}
