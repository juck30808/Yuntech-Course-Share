package Adapter;

public interface AdapteeFormat {
	public void show();
}
