package Adapter;

public interface TargetPlayer {
	public void play(String type);
}
