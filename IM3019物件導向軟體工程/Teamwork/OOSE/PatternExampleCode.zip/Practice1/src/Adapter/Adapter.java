package Adapter;

public class Adapter implements TargetPlayer{
	AdapteeFormat adaptee;
	public void play(String type) {
		if(type == "mp4") {
			adaptee = new Mp4();
			adaptee.show();
		}else if(type == "wmv") {
			adaptee = new Wmv();
			adaptee.show();
		}else {
			System.out.println("not support this format");
		}
	}
}
