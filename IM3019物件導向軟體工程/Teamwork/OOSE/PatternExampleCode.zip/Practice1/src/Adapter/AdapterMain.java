package Adapter;

public class AdapterMain {
	public static void main(String[] args) {
		TargetPlayer t = new Adapter();
		t.play("mp4");
		t.play("wmv");
		t.play("mp3");
	}
}
