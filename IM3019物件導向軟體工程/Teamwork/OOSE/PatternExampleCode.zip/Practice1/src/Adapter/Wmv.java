package Adapter;

public class Wmv implements AdapteeFormat{
	public void show() {
		System.out.println("Playing with wmv");
	}
}
