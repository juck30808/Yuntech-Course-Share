package Adapter;

public class Mp4 implements AdapteeFormat{
	public void show() {
		System.out.println("Playing with mp4");
	}
}
