package ProxySmart;

public interface SystemGUI {
	public void login(String account, String password);
}
