package ProxySmart;

public class LoginProxy implements SystemGUI{
	private int count = 0;
	private Login login = new Login();
	public void login(String account, String password) {
		if(loginControl()) {
			login.login(account, password);
			if(login.flag) {
				count = 0;
				System.out.println("Login successed");
			}else {
				count ++;
				System.out.println("Login fail");
				System.out.println("You left " +(3-count) +" opportunity");
			}
		}else {
			System.out.println("Try it latter .... ");
		}	
	}
	public boolean loginControl() {
		if(count>=3) {
			return false;
		}else {
			return true;
		}
	}
}
