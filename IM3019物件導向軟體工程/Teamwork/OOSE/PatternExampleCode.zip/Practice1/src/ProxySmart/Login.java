package ProxySmart;

public class Login implements SystemGUI{
	public boolean flag;
	public void login(String account, String password) {
		if(account =="123" && password == "123") {
			flag = true;
		}else {
			flag = false;
		}
	}
}
