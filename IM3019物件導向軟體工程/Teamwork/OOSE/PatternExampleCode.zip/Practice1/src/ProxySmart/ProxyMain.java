package ProxySmart;

public class ProxyMain {
	public static void main(String[] args) {
		LoginProxy p = new LoginProxy();
		p.login("789","789");
		p.login("789","789");
		p.login("123","123");
		p.login("789","789");
		p.login("789","789");
		p.login("789","789");
		p.login("789","789");
	}
}
