package AbstractFactory;

public class AbstractFactoryMain {
	public static void main(String[] args) {
		AbstractVender v = new BaseballVender();
		Ball b = v.createBall();
		Clothes c = v.createClothes();
		b.play();
		c.wear();
		System.out.println("********");
		AbstractVender v2 = new BasketballVender();
		Ball b2 = v2.createBall();
		Clothes c2 = v2.createClothes();
		b2.play();
		c2.wear();	
	}
}
