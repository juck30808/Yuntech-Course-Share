package AbstractFactory;

public class Basketball implements Ball{
	@Override
	public void play() {
		System.out.println("having basketball");
	}
}
