package AbstractFactory;

public class BaseballVender extends AbstractVender{
	@Override
	public Ball createBall() {
		return new Baseball();
	}
	@Override
	public Clothes createClothes() {
		return new BaseballClothes();
	}
}
