package AbstractFactory;

public abstract class AbstractVender {
	public abstract Ball createBall();
	public abstract Clothes createClothes();
}
