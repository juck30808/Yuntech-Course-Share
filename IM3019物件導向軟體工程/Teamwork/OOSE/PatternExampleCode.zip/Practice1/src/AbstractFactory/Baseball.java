package AbstractFactory;

public class Baseball implements Ball{
	@Override
	public void play() {
		System.out.println("having baseball");
	}
}
