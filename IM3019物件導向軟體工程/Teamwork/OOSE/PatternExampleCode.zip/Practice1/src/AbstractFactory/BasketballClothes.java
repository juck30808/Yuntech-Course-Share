package AbstractFactory;

public class BasketballClothes implements Clothes{
	@Override
	public void wear() {
		System.out.println("wearing basketball clothes");
	}
}
