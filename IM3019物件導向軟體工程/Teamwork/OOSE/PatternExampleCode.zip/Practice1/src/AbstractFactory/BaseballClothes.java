package AbstractFactory;

public class BaseballClothes implements Clothes{
	@Override
	public void wear() {
		System.out.println("wearing baseball clothes");
	}
}
