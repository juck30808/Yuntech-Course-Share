package AbstractFactory;

public interface Ball {
	public void play();
}
