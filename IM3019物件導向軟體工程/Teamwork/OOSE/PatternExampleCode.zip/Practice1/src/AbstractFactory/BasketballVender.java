package AbstractFactory;

public class BasketballVender extends AbstractVender{
	@Override
	public Ball createBall() {
		return new Basketball();
	}
	@Override
	public Clothes createClothes() {
		return new BasketballClothes();
	}
}
