package AbstractFactory;

public interface Clothes {
	public void wear();
}
