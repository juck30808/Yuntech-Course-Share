package Composite;

public class CompositeMain {
	public static void main(String[] args) {
		Component leaf1 = new Leaf("leaf1");
		Component leaf2 = new Leaf("leaf2");
		Component c = new Composite("c");
		c.add(leaf1);
		c.add(leaf2);
		c.operation();
	}
}
