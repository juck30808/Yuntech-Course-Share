package Composite;

public class Leaf extends Component{
	private String name;
	public Leaf(String n) {
		this.name = n;
	}
	@Override
	public void operation() {
		System.out.println("This is a leaf " +name);
	}
}
