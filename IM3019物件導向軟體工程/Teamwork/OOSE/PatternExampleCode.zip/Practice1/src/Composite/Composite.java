package Composite;

import java.util.ArrayList;

public class Composite extends Component{
	private String name;
	private ArrayList<Component> l = new ArrayList<>();
	public Composite(String n) {
		this.name = n;
	}
	@Override
	public void operation() {
		System.out.println("This is composite " + name);
		System.out.println("It is contain");
		for(Component list:l) {
			list.operation();
		}
	}
	@Override
	public void add(Component c) {
		l.add(c);
	}
	@Override
	public void remove(Component c) {
		l.remove(c);
	}
}
