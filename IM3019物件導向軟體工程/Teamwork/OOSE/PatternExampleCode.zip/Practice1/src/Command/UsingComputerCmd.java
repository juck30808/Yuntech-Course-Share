package Command;

public class UsingComputerCmd implements Command{
	Computer c;
	public UsingComputerCmd(Computer c) {
		this.c = c;
	}
	public void execute() {
		c.plugin();
		c.on();
		c.google();
		c.play();
	}
}
