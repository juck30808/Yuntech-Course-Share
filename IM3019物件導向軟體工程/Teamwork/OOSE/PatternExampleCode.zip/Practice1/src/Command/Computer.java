package Command;

public class Computer implements Device{
	public void on() {
		System.out.println("Computer is on");
	}
	public void off() {
		System.out.println("Computer is off");
	}
	public void plugin() {
		System.out.println("Computer is plugin");
	}
	public void google() {
		System.out.println("Google something ...");
	}
	public void play() {
		System.out.println("Play some game ...");
	}
}
