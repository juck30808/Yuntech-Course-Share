package Command;

public class StopUsingComputerCmd implements Command{
	Computer c;
	public StopUsingComputerCmd(Computer c) {
		this.c = c;
	}
	public void execute() {
		c.off();
	}
}
