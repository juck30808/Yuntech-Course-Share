package Command;

public class CommandMain {
	public static void main(String[] args) {
		RemoteController r = new RemoteController();
		r.setCommand(new UsingComputerCmd(new Computer()));
		r.execute();
		r.setCommand(new StopUsingComputerCmd(new Computer()));
		r.execute();
	}
}
