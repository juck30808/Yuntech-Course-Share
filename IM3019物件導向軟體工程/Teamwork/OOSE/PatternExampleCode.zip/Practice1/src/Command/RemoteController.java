package Command;

public class RemoteController {
	Command c = null ;
	public void setCommand(Command c) {
		this.c = c;
	}
	public void execute() {
		c.execute();
	}
}
