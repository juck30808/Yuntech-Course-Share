package Command;

public interface Device {
	public void on();
	public void off();
	public void plugin();
	public void google();
	public void play();
}
