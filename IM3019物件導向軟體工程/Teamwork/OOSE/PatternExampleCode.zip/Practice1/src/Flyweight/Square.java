package Flyweight;

public class Square implements Shape{
	String name;
	String color;
	public Square() {
		this.name = "Square";
	}
	@Override
	public void draw() {
		System.out.println(this + " " + name + " " + color);
	}
	@Override
	public void setColor(String s) {
		this.color = s;
	}
}
