package Flyweight;

public interface Shape {
	public void draw();
	public void setColor(String s);
}
