package Flyweight;

public class FlyweightMain {
	public static void main(String[] args) {
		ShapeFactory f = new ShapeFactory();
		Shape s = f.getShape("Circle");
		s.setColor("Red");
		s.draw();
		
		Shape s1 = f.getShape("Circle");
		s1.setColor("Blue");
		s1.draw();
		
		Shape s2 =  f.getShape("Circle");
		s2.setColor("Yellow");
		s2.draw();
		System.out.println("****************");
		s.draw();
		s1.draw();
		s2.draw();
		System.out.println("****************");
		
		Shape s3 =  f.getShape("Square");
		s3.setColor("Red");
		s3.draw();
		
		Shape s4 =f.getShape("Square");
		s4.setColor("Blue");
		s4.draw();
		
		Shape s5 = f.getShape("Square");
		s5.setColor("Yellow");
		s5.draw();
		System.out.println("****************");
		s3.draw();
		s4.draw();
		s5.draw();
	}
}
