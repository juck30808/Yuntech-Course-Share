package Flyweight;

import java.util.HashMap;

public class ShapeFactory {
	private HashMap<String,Shape> map = new HashMap<>();
	public Shape getShape(String s) {
		Shape shape = map.get(s);
		if(shape == null) {
			switch(s) {
				case "Circle" :
					shape = new Circle();
					break;
				case "Square" :
					shape = new Square();
					break;
				default:
					break;
			}
			/*
			if(s.equals("Circle")) {
				shape = new Circle();
			}else if (s.equals("Square")) {
				shape = new Square();
			}*/
			map.put(s,shape);
		}
		return map.get(s);
	}
}
