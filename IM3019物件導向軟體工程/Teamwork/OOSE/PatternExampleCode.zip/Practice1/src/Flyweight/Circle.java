package Flyweight;

public class Circle implements Shape{
	private String name;
	private String color;
	public Circle() {
		this.name = "Circle";
	}
	@Override
	public void draw() {
		System.out.println(this + " " + name + " " + color);
	}
	@Override
	public void setColor(String s) {
		this.color = s;
	}
}
