package State;

public class TCPConnection {
	private TCPState s;
	public TCPConnection() {
		s = new TCPClose();
	}
	public void changeState(TCPState s) {
		this.s = s;
	}
	public void open() {
		s.open(this);
	}
	public void close() {
		s.close(this);
	}
	public void acknowledge() {
		s.acknowledge(this);
	}
}
