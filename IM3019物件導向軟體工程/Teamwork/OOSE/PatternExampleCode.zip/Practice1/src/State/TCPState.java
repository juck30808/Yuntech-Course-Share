package State;

public interface TCPState {
	public void open(TCPConnection c);
	public void close(TCPConnection c);
	public void acknowledge(TCPConnection c);
}
