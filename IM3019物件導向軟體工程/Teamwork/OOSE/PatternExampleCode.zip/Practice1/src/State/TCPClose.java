package State;

public class TCPClose implements TCPState{
	@Override
	public void open(TCPConnection c) {
		System.out.println("opening");
		c.changeState(new TCPListen());
	}
	@Override
	public void close(TCPConnection c) {
		System.out.println("closed");
	}
	@Override
	public void acknowledge(TCPConnection c) {
		System.out.println("closed, please open connection first");
	}
}
