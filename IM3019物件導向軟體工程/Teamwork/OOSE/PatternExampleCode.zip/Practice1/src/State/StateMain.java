package State;

public class StateMain {
	public static void main(String[] args) {
		TCPConnection c = new TCPConnection();
		c.open();
		c.open();
		c.acknowledge();
		c.acknowledge();
		c.close();
		c.close();
		c.acknowledge();
	}
}
