package State;

public class TCPEstablish implements TCPState{
	@Override
	public void open(TCPConnection c) {
		System.out.println("connected");
	}
	@Override
	public void close(TCPConnection c) {
		System.out.println("closing");
		c.changeState(new TCPClose());
	}
	@Override
	public void acknowledge(TCPConnection c) {
		System.out.println("already connected");
	}
}
