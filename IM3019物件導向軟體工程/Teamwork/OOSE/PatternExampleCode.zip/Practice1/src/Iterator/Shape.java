package Iterator;

public class Shape {
	String name;
	public Shape(String name) {
		this.name = name;
	}
}
