package Iterator;

import java.util.Iterator;

public class ShapeIterator implements Iterator<Shape>{
	Shape[] s;
	int index;
	public ShapeIterator(Shape[] s) {
		this.s = s;
		index = 0;
	}
	public Shape next() {
		return s[index++];
	}
	@Override
	public boolean hasNext() {
		if(index >=s.length || s[index] == null) {
			return false;
		}else{
			return true;
		}
	}
}
