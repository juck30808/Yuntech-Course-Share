package Iterator;

public class IteratorMain {
	public static void main(String[] args) {
		Shape s1 = new Shape("1");
		Shape s2 = new Shape("2");
		Shape s3 = new Shape("3");
		Shape s4 = new Shape("4");
		Shape[] shapes = {s1,s2,s3,s4};
		ShapeIterator i = new ShapeIterator(shapes);
		while(i.hasNext()) {
			Shape s = i.next();
			System.out.println(s.name);
		}
		System.out.println("------------");
		ShapeIterator2 i2 = new ShapeIterator2(shapes);
		while(i2.hasNext()) {
			Shape s = i2.next();
			System.out.println(s.name);
		}
	}
}
