package prototype;

public class ShallowClone implements Cloneable{
	int y;
	Shadow s;
	public ShallowClone() {
		this.y = 1;
		this.s = new Shadow();
	}
	@Override
	public Object clone() {
		Object c = null;
		try {
			c = super.clone();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return c;
	}
}
