package prototype;

public class PrototypeMain {
	public static void main(String[] args) {
		System.out.println("Shallow Clone Example");
		ShallowClone c1 = new ShallowClone();
		ShallowClone c2 = (ShallowClone)c1.clone();
		c2.s.x = 500;
		System.out.println(c1.y);
		System.out.println(c1.s.x);
		System.out.println("-");
		System.out.println(c2.y);
		System.out.println(c2.s.x);
		System.out.println("*******");
		System.out.println("Deep Clone Example");
		DeepClone c3 = new DeepClone();
		DeepClone c4 = (DeepClone)c3.clone();
		c4.s.x = 500;
		System.out.println(c3.y);
		System.out.println(c3.s.x);
		System.out.println("-");
		System.out.println(c4.y);
		System.out.println(c4.s.x);
		
	}
}
