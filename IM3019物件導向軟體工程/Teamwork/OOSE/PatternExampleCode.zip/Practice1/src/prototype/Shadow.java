package prototype;

public class Shadow implements Cloneable{
	int x;
	public Shadow() {
		this.x = 10;
	}
	@Override
	public Object clone() {
		Object c = null;
		try {
			c = super.clone();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return c;
	}
}
