package prototype;

public class DeepClone implements Cloneable{
	int y;
	Shadow s;
	public DeepClone() {
		this.y = 1;
		this.s = new Shadow();
	}
	@Override
	public Object clone() {
		Object c = null;
		try {
			c = super.clone();
			((DeepClone)c).s = (Shadow)this.s.clone();
		}catch(Exception e){
			e.printStackTrace();
		}
		return c;
	}
}
