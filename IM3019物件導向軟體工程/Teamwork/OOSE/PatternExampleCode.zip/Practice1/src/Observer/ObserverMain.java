package Observer;

public class ObserverMain {
	public static void main(String[] args) {
		Student s1 = new Junior("Students1");
		Student s2 = new Senior("Students2");
		Lesson en = new English();
		Lesson math = new Math();
		en.update(100);
		math.update(50);
		System.out.println("--------------");
		s1.attach(en);
		s2.attach(en);
		s1.attach(math);
		s2.attach(math);
		en.update(60);
		System.out.println("--------------");
		math.update(0);
		System.out.println("--------------");
		en.update(59);
		System.out.println("--------------");
		s1.detach(en);
		s2.detach(math);
		en.update(70);
	}
}
