package Observer;

import java.util.ArrayList;
import java.util.List;

public abstract class Student {
	String name;
	public abstract void attach(Lesson l);
	public abstract void detach(Lesson l);
	public abstract void update(int score);
}
