package Observer;

import java.util.ArrayList;
import java.util.List;

public class Math implements Lesson{
	List<Student> students = new ArrayList<>();
	public void attach(Student s) {
		this.students.add(s);
	}
	public void detach(Student s) {
		this.students.remove(s);
	}
	public void update(int score) {
		for(Student item : students) {
			item.update(score);
		}
	}
}
