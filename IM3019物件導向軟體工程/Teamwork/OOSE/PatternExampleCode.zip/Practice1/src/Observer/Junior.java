package Observer;

import java.util.ArrayList;
import java.util.List;

public class Junior extends Student{
	public Junior(String name) {
		super.name = name;
	}
	public void attach(Lesson l) {
		l.attach(this);
	};
	public void detach(Lesson l) {
		l.detach(this);
	}
	public void update(int score) {
		System.out.println("Junior "+name+" is updating: " + score);
		if(score>=60) {
			System.out.println("You passing this teamwork");
		}else {
			System.out.println("You didn't passing this course but don't need to rework it.");
		}

	}
}
