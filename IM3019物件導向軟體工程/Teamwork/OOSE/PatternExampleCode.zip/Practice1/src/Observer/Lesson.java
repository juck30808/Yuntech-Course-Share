package Observer;

public interface Lesson {
	public void attach(Student s);
	public void detach(Student s);
	public void update(int score);
}
