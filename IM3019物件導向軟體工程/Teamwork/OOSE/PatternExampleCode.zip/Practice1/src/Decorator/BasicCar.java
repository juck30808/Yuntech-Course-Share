package Decorator;

public class BasicCar implements Car{
	@Override
	public void assemble() {
		System.out.println("This is a Basic Car");
	}
}
