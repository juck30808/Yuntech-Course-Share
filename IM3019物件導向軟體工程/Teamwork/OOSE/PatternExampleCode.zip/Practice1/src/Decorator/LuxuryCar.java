package Decorator;

public class LuxuryCar extends CarDecorator{
	public LuxuryCar(Car c) {
		super(c);
	}
	@Override
	public void assemble() {
		c.assemble();
		System.out.println("adding luxury car decoration");
	}
}
