package Decorator;

public interface Car {
	public void assemble();
}
