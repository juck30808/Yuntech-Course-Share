package Facade;

public class FacadeMan {
	public static void main(String[] args) {
		Facade f = new Facade();
		f.doing();
	}
}
