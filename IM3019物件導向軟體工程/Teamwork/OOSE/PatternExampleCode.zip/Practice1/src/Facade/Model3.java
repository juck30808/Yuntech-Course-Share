package Facade;

public class Model3 {
	public void doing() {
		System.out.println("Model3 do something");
	}
}
