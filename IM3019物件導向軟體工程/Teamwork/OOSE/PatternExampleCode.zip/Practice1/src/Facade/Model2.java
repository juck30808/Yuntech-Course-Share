package Facade;

public class Model2 {
	public void doing() {
		System.out.println("Model2 do something");
	}
}
