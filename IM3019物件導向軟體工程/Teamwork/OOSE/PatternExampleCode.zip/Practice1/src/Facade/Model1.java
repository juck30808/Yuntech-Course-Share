package Facade;

public class Model1 {
	public void doing() {
		System.out.println("Model1 do something");
	}
}
