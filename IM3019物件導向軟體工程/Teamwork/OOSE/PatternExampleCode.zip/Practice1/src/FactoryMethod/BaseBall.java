package FactoryMethod;

public class BaseBall implements Ball{
	@Override
	public void play() {
		System.out.println("playing BaseBall");
	}
}
