package FactoryMethod;

public class BasketBall implements Ball{
	@Override
	public void play() {
		System.out.println("playing BasketBall");
	}
}
