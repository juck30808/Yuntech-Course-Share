package FactoryMethod;

public interface Ball {
	public void play();
}
