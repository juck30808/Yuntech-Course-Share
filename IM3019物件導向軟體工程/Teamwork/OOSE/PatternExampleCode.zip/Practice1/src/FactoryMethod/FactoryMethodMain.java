package FactoryMethod;

public class FactoryMethodMain {
	public static void main(String[] args) {
		BallFactory f = new BallVenderFactory("baseball");
		Ball b = f.createBall();
		b.play();
		System.out.println("***********");
		Ball b2 = null;
		BallFactory f2 = new BallVenderFactory("basketball");
		b2 = f2.createBall();
		b2.play();
	}
}
