package FactoryMethod;

public abstract class BallFactory {
	public abstract Ball createBall();
}
