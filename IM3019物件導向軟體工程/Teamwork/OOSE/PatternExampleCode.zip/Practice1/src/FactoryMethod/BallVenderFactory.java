package FactoryMethod;

public class BallVenderFactory extends BallFactory{
	private String Type;
	public BallVenderFactory(String s) {
		this.Type = s;
	}
	@Override
	public Ball createBall() {
		if(Type.equals("baseball")) {
			return new BaseBall();
		}else if(Type.equals("basketball")) {
			return new BasketBall();
		}
		return null;
	}
}
