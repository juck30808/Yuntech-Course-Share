package Template;

public class CashHereCustomer extends Order{
	public void way() {
		System.out.println("Hi! Welcome to this stroe.");
	}
}
