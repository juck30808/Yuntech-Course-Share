package Template;

public class CardPhoneCallCustomer extends Order{
	public void way() {
		System.out.println("Hi! Thinks for your calling.");
	}
	public void how() {
		super.how = "Card";
	}
}
