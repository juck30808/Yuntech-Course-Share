package Template;

public abstract class Order {
	public String how;
	public abstract void way();
	public void how() {
		this.how = "Cash";
	}
	public void what() {
		System.out.println("What do you want to order?");
	}
	private void PayByCash() {
		System.out.println("You pay by cash");
		System.out.println("Thanks for your order");
	}
	private void PayByCard() {
		System.out.println("You pay by card");
		System.out.println("What is your card number?");
		System.out.println("Thanks for your order");
	}
	public final void order() {
		way();
		what();
		how();
		if(how == "Cash") {
			PayByCash();
		}else {
			PayByCard();
		}
	}
}
