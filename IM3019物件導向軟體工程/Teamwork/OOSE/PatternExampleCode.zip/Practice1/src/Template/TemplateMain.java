package Template;

public class TemplateMain {
	public static void main(String[] args) {
		Order order1 = new CashHereCustomer();
		Order order2 = new CashPhoneCallCustomer();
		Order order3 = new CardHereCustomer();
		Order order4 = new CardPhoneCallCustomer();
		order1.order();
		System.out.println("----------------------");
		order2.order();
		System.out.println("----------------------");
		order3.order();
		System.out.println("----------------------");
		order4.order();
	}
}
