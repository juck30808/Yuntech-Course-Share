package Template;

public class CardHereCustomer extends Order{
	public void way() {
		System.out.println("Hi! Welcome to this stroe.");
	}
	public void how() {
		super.how = "Card";
	}
}
