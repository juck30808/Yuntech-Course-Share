package Template;

public class CashPhoneCallCustomer extends Order{
	public void way() {
		System.out.println("Hi! Thinks for your calling.");
	}
}
