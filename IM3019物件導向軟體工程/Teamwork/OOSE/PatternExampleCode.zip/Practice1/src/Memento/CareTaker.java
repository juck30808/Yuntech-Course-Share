package Memento;

import java.util.ArrayList;

public class CareTaker {
	private ArrayList<Memento> list = new ArrayList<>();
	private int i = list.size();
	public void addMemento(Memento m) {
		list.add(m);
	}
	public Memento getMemento() {
		return list.get(i);
	}
}
