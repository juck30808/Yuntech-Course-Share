package Memento;

public class Orginator {
	private String state;
	public Orginator() {
		this.state = "State 1";
	}
	public void setState(String s) {
		this.state = s;
	}
	public Memento saveMemento() {
		return new Memento(state);
	}
	public void restoredFromMemento(Memento m) {
		this.state = m.getSaveState();
	}
	public void print() {
		System.out.println(state);
	}
}
