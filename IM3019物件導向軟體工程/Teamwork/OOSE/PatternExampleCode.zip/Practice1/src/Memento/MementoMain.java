package Memento;

public class MementoMain {
	public static void main(String[] args) {
		Orginator o = new Orginator();
		CareTaker c = new CareTaker();
		o.print();
		c.addMemento(o.saveMemento());
		o.setState("State 2");
		o.print();
		o.restoredFromMemento(c.getMemento());
		o.print();
	}
}
