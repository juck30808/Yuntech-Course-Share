package Memento;

public class Memento {
	private String state;
	public Memento(String s) {
		this.state = s;
	}
	public String getSaveState() {
		return state;
	}
}
