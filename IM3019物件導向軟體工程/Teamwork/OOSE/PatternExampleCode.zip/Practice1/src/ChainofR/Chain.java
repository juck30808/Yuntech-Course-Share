package ChainofR;

public interface Chain {
	public void setNext(Chain c);
	public void process(int n);
}
