package ChainofR;

public class PositiveProcessor implements Chain{
	private Chain next;
	@Override
	public void setNext(Chain c) {
		this.next = c;
	}
	@Override
	public void process(int n) {
		if(n>0) {
			System.out.println("This is positive number");
		}else {
			System.out.println("Positive Passing to the next");
			next.process(n);
		}
	}
}
