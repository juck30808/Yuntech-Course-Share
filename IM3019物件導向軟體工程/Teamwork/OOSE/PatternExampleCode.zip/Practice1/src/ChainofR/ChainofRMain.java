package ChainofR;

public class ChainofRMain {
	public static void main(String[] args) {
		Chain negative = new NegativeProcessor();
		Chain zero = new ZeroProcessor();
		Chain positive = new PositiveProcessor();
		negative.setNext(zero);
		zero.setNext(positive);
		negative.process(500);
	}
}
