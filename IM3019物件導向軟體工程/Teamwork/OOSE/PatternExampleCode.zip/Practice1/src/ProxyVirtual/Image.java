package ProxyVirtual;

public class Image implements Graphic{
	public Image() {
		load();
	}
	@Override
	public void draw() {
		System.out.println("Drawing a image.....");
	}
	public void load() {
		System.out.println("Loading this image...");
	}
}
