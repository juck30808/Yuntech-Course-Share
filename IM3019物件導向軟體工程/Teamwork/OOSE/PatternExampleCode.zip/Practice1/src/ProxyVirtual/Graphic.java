package ProxyVirtual;

public interface Graphic {
	public void draw();
}
