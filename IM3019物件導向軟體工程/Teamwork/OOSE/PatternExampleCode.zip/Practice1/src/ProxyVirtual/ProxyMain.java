package ProxyVirtual;

public class ProxyMain {
	public static void main(String[] args) {
		ImageProxy p = new ImageProxy();
		p.draw();
		p.draw();
	}
}
