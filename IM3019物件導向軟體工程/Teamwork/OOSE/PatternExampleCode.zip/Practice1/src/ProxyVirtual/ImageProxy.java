package ProxyVirtual;

public class ImageProxy implements Graphic{
	Image img = null;
	@Override
	public void draw() {
		if(img == null) {
			this.img = new Image();
		}
		img.draw();
	}

}
