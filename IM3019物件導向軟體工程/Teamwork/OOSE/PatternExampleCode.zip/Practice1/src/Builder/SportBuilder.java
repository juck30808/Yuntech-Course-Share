package Builder;

public class SportBuilder extends Builder{
	private final Car c = new Car("Sprot");
	@Override
	public void createEngine() {
		c.setEngine("Sprot Engine");
	}
	@Override
	public void createBattery() {
		c.setBattery("Sport Battery");
	}
	@Override
	public Car getCar() {
		return c;
	}
}
