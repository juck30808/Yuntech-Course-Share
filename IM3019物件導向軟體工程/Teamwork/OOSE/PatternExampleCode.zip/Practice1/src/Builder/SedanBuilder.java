package Builder;

public class SedanBuilder extends Builder{
	private final Car c = new Car("Sedan");
	@Override
	public void createEngine() {
		c.setEngine("Sedan Engine");
	}
	@Override
	public void createBattery() {
		c.setBattery("Sedan Battery");
	}
	@Override
	public Car getCar() {
		return c;
	}
}
