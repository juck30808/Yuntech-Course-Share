package Builder;

public class BuilderMain {
	public static void main(String[] args) {
		CarDiractor d = new CarDiractor(new SedanBuilder());
		d.build();
		Car c = d.B.getCar();
		System.out.println(c.getType());
		System.out.println(c.getBattery());
		System.out.println(c.getEngine());
		
		System.out.println("********");
		
		CarDiractor d2 = new CarDiractor(new SportBuilder());
		d2.build();
		Car c2 = d2.B.getCar();
		System.out.println(c2.getType());
		System.out.println(c2.getBattery());
		System.out.println(c2.getEngine());
	}
}
