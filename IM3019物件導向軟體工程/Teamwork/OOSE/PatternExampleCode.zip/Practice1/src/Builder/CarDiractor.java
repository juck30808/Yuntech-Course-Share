package Builder;

public class CarDiractor {
	Builder B;
	public CarDiractor(Builder b) {
		this.B = b;
	}
	public void build() {
		B.createBattery();
		B.createEngine();
	}
}
