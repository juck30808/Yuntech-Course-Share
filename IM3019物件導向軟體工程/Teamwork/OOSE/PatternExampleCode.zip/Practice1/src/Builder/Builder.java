package Builder;

public abstract class Builder {
	public abstract void createEngine();
	public abstract void createBattery();
	public abstract Car getCar();
}
