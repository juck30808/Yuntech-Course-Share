package Builder;

public class Car {
	private String Type;
	private String Engine;
	private String Battery;
	public Car(String s) {
		this.Type = s;
	}
	public String getEngine() {
		return Engine;
	}
	public String getBattery() {
		return Battery;
	}
	public String getType() {
		return Type;
	}
	public void setEngine(String s) {
		this.Engine =s;
	}
	public void setBattery(String s) {
		this.Battery = s;
	}
}
