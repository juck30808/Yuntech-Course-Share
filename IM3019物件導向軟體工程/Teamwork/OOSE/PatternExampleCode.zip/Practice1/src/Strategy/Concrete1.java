package Strategy;

public class Concrete1 implements Strategy{
	@Override
	public void perform(int x, int y) {
		int ans = x + y;
		System.out.println("ans: " + ans);
	}
}
