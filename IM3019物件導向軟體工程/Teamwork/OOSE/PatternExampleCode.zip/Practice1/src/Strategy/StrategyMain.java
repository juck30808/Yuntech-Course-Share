package Strategy;

public class StrategyMain {
	public static void main(String[] args) {
		Context c = new Context();
		c.setNumber(5, 5);
		c.setStrategy(new Concrete1());
		c.performStrategy();
		c.setStrategy(new Concrete2());
		c.performStrategy();
	}
}
