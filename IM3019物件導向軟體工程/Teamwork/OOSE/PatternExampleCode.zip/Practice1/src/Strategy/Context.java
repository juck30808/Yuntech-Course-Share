package Strategy;

public class Context {
	private int x, y;
	private Strategy s = null;
	public void setStrategy(Strategy s) {
		this.s = s;
	}
	public void setNumber(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public void performStrategy() {
		s.perform(x, y);
	}
}
