package Strategy;

public interface Strategy {
	public void perform(int x, int y);
}
