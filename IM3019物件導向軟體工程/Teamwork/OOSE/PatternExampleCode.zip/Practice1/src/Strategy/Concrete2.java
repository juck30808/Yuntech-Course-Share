package Strategy;

public class Concrete2 implements Strategy{
	@Override
	public void perform(int x, int y) {
		int ans = x * y;
		System.out.println("ans: " + ans);
	}
}
