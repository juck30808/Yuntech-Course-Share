package Memento_Command;

public class memento {
	public String text;
	public memento(String text) {
		this.text = text;
	}
	
	public String getText() {
		return this.text;
	}
}
