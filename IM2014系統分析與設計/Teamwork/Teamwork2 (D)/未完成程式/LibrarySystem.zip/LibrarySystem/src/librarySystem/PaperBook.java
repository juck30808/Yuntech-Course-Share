package librarySystem;
import java.util.Date;
public class PaperBook extends book{
			private String state;
			private String borrower;
			private int price;
			private String borrowerTime;
			public void view()
		{
			//�o�]��gui����
		}
		public void setPaperBook(
			String IbookID,
			String IbookTitle,
			String Iauthor,
			String Ipublisher,
			String IpublicationDate,
			String Isummary,
			String Istate,
			String Iborrower,
			String IborrowerTime,
			int Iprice
		)
		{
			super.bookID=IbookID;
			super.bookTitle=IbookTitle;
			super.author=Iauthor;
			super.publisher=Ipublisher;
			super.publicationDate=IpublicationDate;
			super.summary=Isummary;
			state=Istate;
			borrower=Iborrower;
			price=Iprice;
			borrowerTime=IborrowerTime;
		}
		public void setbookState(String i) 
		{
			state=i;
		}
		public void setBorrower(String i) 
		{
			borrower=i;
		}
		public void setBorrowerTime(String i) 
		{
			borrowerTime=i;
		}
		public String getbookID() 
		{
			return (super.bookID);
		}
		public String getbookTitle() 
		{
			return (super.bookTitle);
		}
		public String getauthor() 
		{
			return (super.author);
		}
		public String getpublisher() 
		{
			return (super.publisher);
		}
		public String getpublicationDate() 
		{
			return (super.publicationDate);
		}
		public String getsummary() 
		{
			return (super.summary);
		}
		public String getstate() 
		{
			return state;
		}
		public String getborrower() 
		{
			return borrower;
		}
		public int getprice() 
		{
			return price;
		}
		public String getborrowerTime() 
		{
			return borrowerTime;
		}
}
