package librarySystem;

public abstract class book{
	protected String bookID;
	protected String bookTitle;
	protected String author;
	protected String publisher;
	protected String publicationDate;
	protected String summary;
	public abstract void view();
}
