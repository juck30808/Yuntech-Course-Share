package librarySystem;
public class SendMailSSL{    
 public static void main(String[] args) {    
     //from,password,to,subject,message  
     Mailer.send("kencs16358@gmail.com","ken0937565169","kencs16358@gmail.com","hello javatpoint","How r u?");  
     //change from, password and to  
 }    
}    