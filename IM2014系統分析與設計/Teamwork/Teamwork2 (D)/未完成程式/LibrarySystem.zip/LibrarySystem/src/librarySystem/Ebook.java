package librarySystem;
import javax.swing.*;

import java.io.*;
import javax.swing.*;


public class Ebook extends book{
	private String bookContext;
	public void view()
	{
	}
	public void setEbook(
	String IbookID,
	String IbookTitle,
	String Iaurhor,
	String Ipublisher,
	String IpublicationDate,
	String Isummary,
	String IbookContext
	)
	{
		super.bookID=IbookID;
		super.bookTitle=IbookTitle;
		super.author=Iaurhor;
		super.publisher=Ipublisher;
		super.publicationDate=IpublicationDate;
		super.summary=Isummary;
		bookContext=IbookContext;
	}
	
	public String getbookID() 
	{
		return (super.bookID);
	}
	public String getbookTitle() 
	{
		return (super.bookTitle);
	}
	public String getauthor() 
	{
		return (super.author);
	}
	public String getpublisher() 
	{
		return (super.publisher);
	}
	public String getpublicationDate() 
	{
		return (super.publicationDate);
	}
	public String getsummary() 
	{
		return (super.summary);
	}
	public String getbookContext() 
	{
		System.out.println(bookContext);
		return bookContext;
	}
}
