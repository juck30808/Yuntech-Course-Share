package abcd;

public class aaaa {

	public static void main(String[] args) {
		String i = "member";
		asdg.abc(i);

	}

}
