import java.util.*;

public class PaymentMachine {
	int fee = 1;
	int pay_money;
	String plate;
	Date entertime;
	Date leavetime;
	boolean Status_Payment=false;
	double diff;
	int cash,icash;
	int paymoney,balance;
	String paymeth;
	Register r = new Register();
	ParkingInfo info;
	Scanner scanner = new Scanner(System.in);
	
	public int computefee() {
		
		System.out.println("�п�J���P���X�G");
        plate = scanner.nextLine();
        info = r.getmapvalue(plate);
        System.out.println(info);
		//entertime = info.entertime;
		leavetime = new Date();
		leavetime.getTime();
		//diff=leavetime.getTime()-entertime.getTime();
		//fee=(int)Math.ceil(diff)*200;
		return fee;
	}
	public void payment() {
		System.out.println("��ܥI�ڤ覡(cash or icash)�G");
		paymeth = scanner.nextLine();
		while(fee!=0) {
			if(paymeth=="cash") {
				paymoney = scanner.nextInt();
				balance= paymoney - fee;
				fee =0;
				Status_Payment=true;
				System.out.printf("�� %d ��/n",balance);
			}else if(paymeth=="icash"){
                paymoney = scanner.nextInt();
				balance= paymoney - fee;
				if(balance >fee) {
				System.out.printf("���ڦ��\",balance);
				fee =0;
				Status_Payment=true;
				}else
				System.out.printf("�l�B����",balance);	
				
			}
		}
        info = r.getmapvalue(plate);
        info.Updatepaystate(Status_Payment);
	}
}
