import java.util.*;

public class Register {
	
	ParkingInfo parkinfo;
	Map<String,ParkingInfo> parkingmap = new HashMap <String,ParkingInfo>();	
	public void Registercarinfo(String car_LIcense,int car_space) {
		parkinfo = new ParkingInfo(car_LIcense,car_space);
		parkingmap.put(car_LIcense,parkinfo);
        System.out.println(parkingmap.get("plate"));
	}
	
	
	public ParkingInfo getmapvalue(String plate) {
		// �� for-loop ���X�C�@�� key �P value
		
		ParkingInfo aValue = parkingmap.get("plate");
		    
		
		return aValue;
	}

}
