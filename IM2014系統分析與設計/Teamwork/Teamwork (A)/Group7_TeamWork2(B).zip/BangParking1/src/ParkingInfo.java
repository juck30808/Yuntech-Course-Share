import java.util.*;

public class ParkingInfo {
	
	String car_LIcense;
	int car_space;
	Date entertime;
	boolean paystate;
	
	public ParkingInfo(String LIcense,int space) {
		car_LIcense = LIcense;
		car_space = space;
		entertime = new Date();
		entertime.getTime();
		System.out.println("Time:" + entertime);
		paystate = false;
	}
	
	public void Updatepaystate(boolean pay) { //��s�I�ڪ��A
		this.paystate=pay;
	}	
	
	
}
