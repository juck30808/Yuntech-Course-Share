import java.util.*;
public class Controller {
	int car_space;
	int sensorNum;
	int plate;
	String position;
	Car c = new Car();
	String s=c.get_LicenseNum();
	PaymentMachine  pm =new PaymentMachine();
	Register r = new Register();
	Random ran = new Random();
	ParkingSpace p = new ParkingSpace();
	Gate gate =new Gate();
	Scanner scanner = new Scanner(System.in);
	
	public void park() {
		if(p.getStatus())
		p.parking();
		c.InputLIcense();
		System.out.println("Sensor�P�����ȡG");
        sensorNum = scanner.nextInt();
        System.out.println("�Ȥᰱ����m��" + sensorNum);
        r.Registercarinfo(c.get_LicenseNum(),sensorNum);
		System.out.println("Sensor�P���찱�������}(enter or leave)�G");
		scanner.nextLine();
        position = scanner.nextLine();
        
        p.controlspacestate(sensorNum,position);
		//car_space=ran.nextInt(10)+1;
		
	}
	
	public void register() {
		r.Registercarinfo(s,car_space);//��parkingInfo��T�� register
	}
	public void getpaymentmachine() {
		pm.computefee();
		pm.payment();
	}
}
