import java.util.*;
public class Car {
    String LicenseNum;
    

    Scanner scanner = new Scanner(System.in);
    public void InputLIcense() {
    	 System.out.println("���o���P");
    	 LicenseNum= scanner.next();
    }
    
    public String get_LicenseNum(){
    	return LicenseNum;
    }
}
