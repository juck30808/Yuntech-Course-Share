import java.util.*;

public class Gate {
	private boolean gateStatus = false;
	Scanner scanner = new Scanner(System.in);
	ParkingSpace p=new ParkingSpace();
	int Car_status;
	public void controlenterGateStatus() {
		if(p.getStatus()) {
			Car_status  = scanner.nextInt();
			switch(Car_status) { 
            case 1:
                System.out.println("���l���i��"); 
                gateStatus = true;
                break; 
            case 2:
                System.out.println("���l�w�i��"); 
                gateStatus = false;
                break; 
           }
		}
	 	
	}
	
	public void controlleaveGateStatus() {
		if(p.getStatus()) {
			Car_status  = scanner.nextInt();
			switch(Car_status) { 
            case 1:
                System.out.println("���l������"); 
                gateStatus = true;
                break; 
            case 2:
                System.out.println("���l�w����"); 
                gateStatus = false;
                break; 
           }
		}
	 	
	}
	
	
}
