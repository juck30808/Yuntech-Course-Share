
public class park_main {
	public static void main(String[] args) {
		Controller controller =new Controller();
		controller.park(); 
		controller.register();
		controller.getpaymentmachine();
		
	}
}
