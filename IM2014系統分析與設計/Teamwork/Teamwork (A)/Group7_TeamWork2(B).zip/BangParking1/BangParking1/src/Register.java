import java.util.*;

public class Register {
	ParkingInfo info;
	private String[] plateTemp = new String[10];
	private Date enterTime;
	private Map<String,ParkingInfo> parkingMap = new HashMap <String,ParkingInfo>();
	
	Register() {
		for(int i = 0 ; i < plateTemp.length ; i++) {
			plateTemp[i] = "Empty";
		}
	}
	
	public void tempSavePlate(String plate) {
		//�Ȧs���P
		for(int i = 0; i < plateTemp.length ; i++) {
			if(plateTemp[i].equals("Empty")) {
				plateTemp[i] = plate;
				break;
			}
		}	
		recordEnrtyTime();
	}
	public void recordEnrtyTime() {
		enterTime = new Date();
		System.out.println("\n[Enter time recorded:]");
		System.out.print(enterTime);
		System.out.print("\n\n");
	}
	public void createInfo(String plate,int spaceNum) {
		if(findTempPlate(plate)) {//use plate which controller got from space 
			                      //to check temporary plate array.
			//if plate can be find in temporary plate array, register will create information.
			info = new ParkingInfo(plate,spaceNum,this.enterTime);
			parkingMap.put(plate,info);
		}
	}
	public boolean findTempPlate(String plate) {
		for(int i=0; i < plateTemp.length ; i++) {
			if(plateTemp[i].equals(plate)) {
				return true;
			}
		}
		return false;
	}
	public ParkingInfo getMapValue(PaymentMachine pm) {
		// use for-loop to get each key and  value
		for(String aKey : parkingMap.keySet()) {
		    if(aKey.equals(pm.getSearchPlate())) {
		    	info = parkingMap.get(aKey);
		    }
		}
		System.out.print(info.getCarLicense());
		return info;
	}
	public void requestUpdate(String plate) {
		for(String aKey : parkingMap.keySet()) {
		    if(aKey.equals(plate)) {
		    	info = parkingMap.get(aKey);
		    	info.updateInfo();
		    }
		}
	}
}
