import java.util.*;
public class Car {
	Scanner scanner = new Scanner(System.in);
    private String licensePlate;
    Car(String plate){
    	this.licensePlate = plate;
    }
    public String getLicensePlate() {
    	return this.licensePlate;
    }
}
