import java.util.*;
import java.text.SimpleDateFormat;
public class PaymentMachine {
	Scanner scanner = new Scanner(System.in);
	Register register;
	ParkingInfo info;
	private Date leaveTime;
	private String searchPlate;
	private int fee=0;
	private int[] feeTable = {200,0,400};//w1w2w4w5:200,w3=0,w6~w7:400
	private int payType; //1 use cash 2 use icash
	private int money;
	private int change =0;
	private int printReceipt;//1.Print 2.Not Print
	private double diff;
	private String week;
	
	PaymentMachine(Register r){
		this.register = r;
	}
	public void payBill(String plate) {
		System.out.println("Please choose a way to pay the bill:");
		System.out.println("(If you want to pay by cash, input 1");
		System.out.println("If you want to pay by icash, input 2)");
		payType = scanner.nextInt();
		while(info.getPayState() == false) {
			if(payType ==1) {
				System.out.printf("Input money amount (fee = %d):\n",fee);
				money = scanner.nextInt();
				if(money-fee ==0) {
					System.out.println("\nTransaction success.");
					register.requestUpdate(plate);
				}else if(money-fee>0) {
					change = money-fee;
					System.out.println("\nTransaction success.");
					System.out.printf("Here's your change: %d dollars.\n\n",change);
					register.requestUpdate(plate);
				}else System.out.println("Insufficient amount!\n");	
			}else if(payType ==2) {
				System.out.printf("Input icash balance (fee = %d):\n",fee);
				money = scanner.nextInt();
				if(money-fee ==0) {
					System.out.println("\nTransaction success.");
					System.out.printf("Here's your card's balance: 0 dollars.\n\n");
					register.requestUpdate(plate);
				}else if(money-fee>0) {
					change = money-fee;
					System.out.println("\nTransaction success.");
					System.out.printf("Here's your card's balance: %d dollars.\n\n",change);
					register.requestUpdate(plate);
				}else System.out.println("Insufficient balance!\n");
			}
		}
		printReceipt();
	}
	public void searchParkInfo() {
		System.out.println("Please input your car plate to search your bill.");
		searchPlate = scanner.nextLine();//Customer input car plate on payment machine
		if((register.getMapValue(this).getCarLicense().equals(searchPlate))) {//���O�̨ϥΪ����P �� ParkingInfo �x�s�����P
			info = register.getMapValue(this);
			setLeaveTime();
			computeFee();
			payBill(searchPlate);
		}else {
			System.out.println("\n\n[Sorry, we can't find your parking record.");
			System.out.println("Please input your plate once again]");
			searchParkInfo();
		}
	}
	public void setLeaveTime() {
		leaveTime = new Date();
		convertTime(leaveTime);
		System.out.println("\nLeave time:"+leaveTime);
	}
	public void  computeFee(){
		diff=leaveTime.getTime()-info.getEnterTime().getTime();
		if(week.equals("3")) {
			fee=(int)Math.ceil(diff/1000)*feeTable[1];//w3
		}else if((week.equals("6"))||(week.equals("7"))) {//w6~w7
			fee=(int)Math.ceil(diff/1000)*feeTable[2];
		}else{
			fee=(int)Math.ceil(diff/1000)*feeTable[0];//w1w2w4w5
		}
		System.out.printf("Total Fee: %d.\n\n",fee);
	}
	public void printReceipt() {
		System.out.printf("Would you like to print receipt?\n");
		System.out.printf("(If you want, input 1.\n");
		System.out.printf("If you don't want, input 2.)\n");
		printReceipt = scanner.nextInt();
		if(printReceipt ==1) {
			System.out.println("\n[Receipt]");
			System.out.printf("Car Plate: %5s\n",info.getCarLicense());
			System.out.print("Enter Time:  " + info.getEnterTime() +"\n");
			System.out.printf("Leave Time:  " + leaveTime +"\n");
			System.out.printf("Total fee: %6d\n",fee);
			if(payType == 1) {
				System.out.printf("Cash: %11d\n",money);
			}else if(payType == 2) {
				System.out.printf("Debit : %11d\n",money);
			}
			if(payType == 1) {
				System.out.printf("Change: %8d\n",change);
			}else if(payType == 2) {
				System.out.printf("Card's balance: %8d\n",change);
			}
		}
	}
	public String getSearchPlate() {
		return this.searchPlate;
	}
	public void convertTime(Date time) {
		SimpleDateFormat sdf = new SimpleDateFormat("u");
		week = sdf.format(time);
	}
}
