import java.util.*;
public class Controller {
	Scanner scanner = new Scanner(System.in);
	Gate aGate;
	ParkingSpace allParkingSpace;
	Register aRegister;
	Car aCar;
	
	Controller(String p,ParkingSpace aps){
		this.aGate = new Gate();
		this.allParkingSpace = aps;
		this.aRegister = new Register();
		this.aCar = new Car(p);
	}
	public void requestEnter() {
		if(allParkingSpace.checkSpacesState()) { //to check if there's any space available
			aRegister.tempSavePlate(aCar.getLicensePlate());
			//call gate to open
			aGate.open();
			allParkingSpace.occupiedSpace();
			aGate.enter();
			//call gate to close
			aGate.close();
		}else {
			System.out.println("[Sorry. There is no space available.]");
		}
	}
	public void setParkSpaceNum() {
		System.out.println("Choose 1 parking space (1~10)");
		allParkingSpace.setSpaceNum(scanner.nextInt());
		allParkingSpace.park();
	}
	public int getParkSpaceNum() {
		return allParkingSpace.getSpaceNum();
	}
	public void requestCreateInfo(String plate,int spaceNum){
		aRegister.createInfo(plate,spaceNum);
	}
	public void requestLeave() {
		aGate.open();
		aGate.leave();
		aGate.close();
	}
}
