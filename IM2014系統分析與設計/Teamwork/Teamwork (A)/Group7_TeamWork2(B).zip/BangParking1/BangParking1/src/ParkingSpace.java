import java.util.*;
public class ParkingSpace {
	Scanner scanner = new Scanner(System.in);
	private int[] spaces = new int[10]; //assume we have 10 space, empty is 0, occupied is 1.
	private int spaceNum;
	private static int checkOccupiedNum=0; //use to check how many spaces was occupied.
	
	ParkingSpace(){
		//Initialized all spaces. (Default is all empty)
		for(int i=0; i<spaces.length; i++) {
			spaces[i] = 0;
		}
	}
	public boolean checkSpacesState(){
		if(checkOccupiedNum == 10) {
			return false; //all spaces are occupied
		}else {
			return true;
		}
	}
	public void park() {
		//to check each space was occupied or not
		while(spaces[spaceNum-1] != 0) {
			System.out.printf("Sorry. The %dth space is already occupied.\n ",spaceNum);
			System.out.println("Please choose another space.");
			spaceNum = scanner.nextInt();
		}
		spaces[spaceNum-1] = 1; //customer occupied the space
		System.out.printf("\nPark car in the %dth space successfully.\n\n", spaceNum);
	}
	public void occupiedSpace() {
		checkOccupiedNum +=1; //if it plus to ten, represent no space available.
	}
	public void leaveSpace() {
		checkOccupiedNum -=1;
	}
	public int getSpaceNum() {
		return this.spaceNum;
	}
	public void setSpaceNum(int sn) {
		this.spaceNum = sn;
	}
}
