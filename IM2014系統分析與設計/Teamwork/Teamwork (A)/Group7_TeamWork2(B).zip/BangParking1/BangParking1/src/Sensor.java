import java.util.*;
public class Sensor {
	Scanner scanner= new Scanner(System.in);
	private String plate;
	public void senseSimulate() {
		System.out.println("[Simulate sensor detected the car.]");
	}
	public String getPlate() {
		return this.plate;
	}
	public void senseCar() {
		System.out.println("[Simulate sensor of space detected the car.]");
		System.out.println("Input plate on the space (simulate the sensor's work) to create informaiton:");
		this.plate = scanner.nextLine();
	}
}
