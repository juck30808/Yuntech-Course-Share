import java.util.*;
public class park_main {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("[Welcome to BangParking System!");
		System.out.println("We assume that we have 10 parking spaces.]");
		System.out.println("[W1,W2,W4,W5  $200/second]");
		System.out.println("[W4           $0/second]");
		System.out.println("[W6,W7        $400/second]");
		System.out.println("----------");
		String plate;
		aSensor aSensor = new aSensor();
		ParkingSpace allPS = new ParkingSpace();
		aSensor.senseSimulate();
		System.out.println("Please enter the car plate (Simulate sensor's task)");
		plate = scanner.nextLine();
		Controller aController =new Controller(plate,allPS);
		//Controller judge is there any car space available.
		//We assume that still have spaces.
		aController.requestEnter();
		System.out.println("----------");
		//After entering, customer will choose a space to park.
		//choose one space
		System.out.println("Customer will choose a space to park");
		aController.setParkSpaceNum();
		aSensor.senseCar();
		//Controller use space number and car plate to call Register to create ParkingInfo
		aController.requestCreateInfo(aSensor.getPlate(),aController.getParkSpaceNum());
		System.out.println("----------");
		System.out.println("(When customer wants to leave.)");
		PaymentMachine aPM = new PaymentMachine(aController.aRegister);
		aPM.searchParkInfo();
		System.out.println("----------");
		aSensor.senseSimulate();
		System.out.println("\n[Thankyou very much! Have a nice day!]");
		aController.requestLeave();
	}
}
