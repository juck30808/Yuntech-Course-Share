public class Gate {
	public void open() { //open
		System.out.println("[Open gate]");
	}
	public void enter() { //enter
		System.out.println("Car enters the parking lot.");
	}
	public void close() { //close
		System.out.println("[Close gate]");
	}
	public void leave() { //leave
		System.out.println("(Car leaves the parking lot.)");
	}
}
