import java.util.*;

public class ParkingInfo {
	private String carLicense;
	private int carSpace;
	private Date enterTime;
	private boolean payState;
	
	ParkingInfo(String plate,int spaceNum,Date time){
		this.carLicense = plate;
		this.carSpace = spaceNum;
		this.enterTime = time;
		this.payState = false;
		System.out.println("\n[Parking Information Created"
				+ " as Follow]"+"\nCar plate: "+carLicense+" "
						+ "\nSpace number: "+carSpace+" \nEnter time: "
								+ ""+enterTime+"\nPayment Status: "+payState);
	}
	public void updateInfo() {
		this.payState = true;
	}
	public String getCarLicense() {
		return this.carLicense;
	}
	public Date getEnterTime() {
		return this.enterTime;
	}
	public boolean getPayState() {
		return this.payState;
	}
}
